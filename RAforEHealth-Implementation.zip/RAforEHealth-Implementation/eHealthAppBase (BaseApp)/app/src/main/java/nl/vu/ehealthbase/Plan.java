package nl.vu.ehealthbase;

abstract class Plan {
    abstract void plan();
    abstract void callExecute();
}
