package nl.vu.ehealthbase;

abstract class Execute {
    abstract void execute();
}
