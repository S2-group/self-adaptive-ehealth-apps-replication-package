package nl.vu.ehealthbase;

abstract class Monitor {
    abstract void monitor();
    abstract void callAnalyse();
}
