package nl.vu.ehealthbase;

abstract class Analyse {
    abstract void analyse();
    abstract void callPlan();
}
