package nl.vu.ehealth;

abstract class Plan {
    abstract void plan();
    abstract void callExecute();
}
