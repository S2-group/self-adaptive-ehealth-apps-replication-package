package nl.vu.ehealth;

abstract class Monitor {
    abstract void monitor();
    abstract void callAnalyse();
}
