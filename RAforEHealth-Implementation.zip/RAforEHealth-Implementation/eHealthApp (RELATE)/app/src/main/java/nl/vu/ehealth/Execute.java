package nl.vu.ehealth;

abstract class Execute {
    abstract void execute();
}
