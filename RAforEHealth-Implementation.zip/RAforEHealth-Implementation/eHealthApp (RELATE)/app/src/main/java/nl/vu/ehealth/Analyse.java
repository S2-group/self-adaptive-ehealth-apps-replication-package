package nl.vu.ehealth;

abstract class Analyse {
    abstract void analyse();
    abstract void callPlan();
}
